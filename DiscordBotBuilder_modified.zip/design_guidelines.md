# Discord Bot Management Dashboard - Design Guidelines

## Design Approach

**Selected Approach:** Design System - Material Design + Discord-Inspired
**Justification:** This is a data-heavy administrative dashboard requiring clear information hierarchy, consistent patterns, and familiar Discord aesthetics for bot managers.

**Primary References:**
- Discord Developer Portal (color scheme and bot-related UI patterns)
- Vercel Dashboard (clean metrics and deployment status)
- Railway Dashboard (modern DevOps panel aesthetics)

---

## Core Design Elements

### A. Color Palette

**Dark Mode Primary (Default):**
- Background Base: 220 13% 9% (Deep navy-black, Discord-inspired)
- Surface/Cards: 220 13% 12%
- Surface Elevated: 220 13% 15%
- Border: 220 10% 20%

**Accent Colors:**
- Primary (Blurple - Discord brand): 235 86% 65%
- Success: 142 71% 45%
- Warning: 38 92% 50%
- Danger: 0 84% 60%
- Info: 199 89% 48%

**Text:**
- Primary: 210 20% 98%
- Secondary: 215 20% 65%
- Muted: 215 15% 50%

### B. Typography

**Font Stack:**
- Primary: 'Inter', system-ui, sans-serif
- Monospace: 'JetBrains Mono', 'Fira Code', monospace (for bot IDs, tokens)

**Scale:**
- Dashboard Title: text-3xl font-bold
- Section Headers: text-xl font-semibold
- Card Titles: text-lg font-medium
- Body Text: text-base
- Metrics/Stats: text-sm font-medium
- Labels: text-xs uppercase tracking-wide

### C. Layout System

**Spacing Primitives:** Tailwind units of 2, 4, 6, 8, 12, 16
- Card padding: p-6
- Section gaps: gap-6 or gap-8
- Component margins: mb-4, mb-6, mb-8
- Grid gaps: gap-4 (tight) or gap-6 (comfortable)

**Dashboard Structure:**
- Sidebar: 16rem fixed width (w-64)
- Main content: Fluid with max-w-7xl container
- Grid layouts: 3-column for metrics, 2-column for detailed views

### D. Component Library

**Navigation:**
- Fixed sidebar with bot branding at top
- Icon + label navigation items
- Active state: bg-primary/10 with left border accent
- Collapsible on mobile (hamburger menu)

**Stat Cards:**
- Grid of 3-4 metrics across top of dashboard
- Large number display (text-3xl font-bold)
- Icon on left, trend indicator on right
- Subtle gradient background for emphasis cards

**Data Tables:**
- Striped rows for readability (bg-surface/50 on alternate)
- Fixed header on scroll
- Action buttons on hover for each row
- Pagination at bottom

**Command Usage Charts:**
- Bar charts for command frequency
- Line graphs for usage over time
- Donut chart for command category distribution
- Use Chart.js or Recharts with dark theme

**Forms/Settings:**
- Grouped sections with dividers
- Toggle switches for boolean settings
- Dropdown selects for options
- Save button fixed bottom-right when form dirty

**Bot Status Indicators:**
- Large status badge (Online: green, Offline: red, Warning: yellow)
- Uptime counter with icon
- Last restart timestamp
- Server count and user count metrics

**Modals/Overlays:**
- Dark backdrop (bg-black/50)
- Centered modal with rounded-lg
- Close button top-right
- Confirm/Cancel actions bottom-right

### E. Animations

**Minimal and Purposeful:**
- Sidebar slide-in on mobile: duration-200
- Card hover lift: transition-transform hover:scale-[1.02]
- Loading states: Subtle pulse animation
- No excessive page transitions - instant navigation preferred

---

## Dashboard-Specific Layouts

### Main Dashboard View
**Structure:**
- Top bar: Bot name, status indicator, quick actions (restart, logs)
- Metrics row: 4-card grid showing: Total Servers, Active Users, Commands/Day, Uptime
- Two-column layout below:
  - Left (2/3): Command usage chart (past 7 days)
  - Right (1/3): Recent activity feed
- Bottom section: Server list table with search/filter

### Command Management Page
**Structure:**
- Header with "Add Command" button
- Filter bar: Category tabs (Economy, Games, Moderation, Fun)
- Card grid showing each command with:
  - Command name and description
  - Usage count (last 30 days)
  - Enabled/Disabled toggle
  - Edit button

### Settings Page
**Structure:**
- Tabbed interface: General, Economy, Moderation, Integrations
- Each tab: Form sections with descriptive headers
- Inline help text for complex settings
- Save indicator (unsaved changes warning)

### Server Details View
**Structure:**
- Server icon and name header
- Quick stats: Members, Channels, Command usage
- Configuration overrides specific to this server
- Audit log of bot actions in server

---

## Visual Enhancements

**Iconography:**
- Use Lucide React or Heroicons for consistent icon style
- Bot-specific icons: Servers (server icon), Commands (terminal), Users (users icon)
- Status icons always paired with color (don't rely on color alone)

**Data Visualization:**
- Dark theme chart colors matching accent palette
- Tooltips on hover for detailed metrics
- Responsive charts that scale on mobile

**Empty States:**
- Illustration or large icon centered
- Helpful text explaining what will appear
- Primary action button (e.g., "Connect your bot")

**Loading States:**
- Skeleton screens matching component structure
- Shimmer effect on loading cards
- Never block entire UI - show what's loaded

---

## Accessibility & Responsiveness

**Dark Mode:**
- Default and only theme (no light mode needed for admin panel)
- Sufficient contrast ratios (WCAG AA minimum)
- No pure white text (use 98% lightness for comfort)

**Responsive Breakpoints:**
- Mobile (<768px): Stacked layout, collapsible sidebar
- Tablet (768-1024px): 2-column grids instead of 3
- Desktop (>1024px): Full multi-column layouts

**Interactive States:**
- Hover: Subtle background change or scale
- Focus: 2px outline in primary color
- Disabled: 50% opacity with cursor-not-allowed

---

## Critical Design Mandates

1. **Information Density:** Balance showing comprehensive data without overwhelming - use collapsible sections for detailed info
2. **Real-time Updates:** Visual indicators when data refreshes (pulse animation on updated metrics)
3. **Error States:** Clear error messages with suggested actions, never just "Error"
4. **Quick Actions:** Frequently used actions (restart bot, view logs) always accessible from any page
5. **Search Everything:** Global search bar for servers, commands, users
6. **Mobile-First Metrics:** Most critical stats visible even on small screens

This dashboard prioritizes clarity, efficiency, and familiar Discord aesthetics while maintaining professional admin panel standards.