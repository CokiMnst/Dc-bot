import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Activity, Users, Server, TrendingUp, Zap, MessageSquare } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, LineChart, Line } from 'recharts';

interface BotStats {
  status: 'online' | 'offline' | 'idle';
  totalServers: number;
  totalUsers: number;
  commandsToday: number;
  uptimeSeconds: number;
  totalCommands: number;
  messagesProcessed: number;
}

interface CommandUsage {
  name: string;
  count: number;
}

export default function Dashboard() {
  const { data: stats, isLoading: statsLoading } = useQuery<BotStats>({
    queryKey: ['/api/bot/stats'],
  });

  const { data: commandUsage, isLoading: commandsLoading } = useQuery<CommandUsage[]>({
    queryKey: ['/api/bot/commands/usage'],
  });

  const formatUptime = (seconds: number) => {
    const days = Math.floor(seconds / 86400);
    const hours = Math.floor((seconds % 86400) / 3600);
    const mins = Math.floor((seconds % 3600) / 60);
    return `${days}d ${hours}h ${mins}m`;
  };

  const getStatusColor = (status: string) => {
    switch(status) {
      case 'online': return 'bg-status-online';
      case 'idle': return 'bg-status-away';
      case 'offline': return 'bg-status-offline';
      default: return 'bg-status-offline';
    }
  };

  const StatCard = ({ title, value, icon: Icon, trend, loading }: any) => (
    <Card className="hover-elevate transition-all duration-200">
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-sm font-medium text-muted-foreground">{title}</CardTitle>
        <Icon className="h-4 w-4 text-muted-foreground" />
      </CardHeader>
      <CardContent>
        {loading ? (
          <Skeleton className="h-8 w-24" />
        ) : (
          <>
            <div className="text-3xl font-bold">{value}</div>
            {trend && (
              <p className="text-xs text-muted-foreground mt-1">
                <TrendingUp className="inline h-3 w-3 mr-1" />
                {trend}
              </p>
            )}
          </>
        )}
      </CardContent>
    </Card>
  );

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold" data-testid="text-dashboard-title">HELLBORNTV Bot</h1>
          <p className="text-muted-foreground mt-1">Discord Bot Management Dashboard</p>
        </div>
        <div className="flex items-center gap-3">
          {statsLoading ? (
            <Skeleton className="h-6 w-24" />
          ) : (
            <Badge 
              variant="outline" 
              className={`${getStatusColor(stats?.status || 'offline')} text-white border-0 px-3 py-1`}
              data-testid="badge-bot-status"
            >
              <span className="relative flex h-2 w-2 mr-2">
                <span className={`animate-ping absolute inline-flex h-full w-full rounded-full ${getStatusColor(stats?.status || 'offline')} opacity-75`}></span>
                <span className={`relative inline-flex rounded-full h-2 w-2 bg-white`}></span>
              </span>
              {stats?.status.toUpperCase() || 'OFFLINE'}
            </Badge>
          )}
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <StatCard
          title="Total Servers"
          value={stats?.totalServers?.toLocaleString() || '0'}
          icon={Server}
          trend="+2 this week"
          loading={statsLoading}
        />
        <StatCard
          title="Active Users"
          value={stats?.totalUsers?.toLocaleString() || '0'}
          icon={Users}
          trend="+125 today"
          loading={statsLoading}
        />
        <StatCard
          title="Commands Today"
          value={stats?.commandsToday?.toLocaleString() || '0'}
          icon={Zap}
          trend="+15% from yesterday"
          loading={statsLoading}
        />
        <StatCard
          title="Uptime"
          value={stats ? formatUptime(stats.uptimeSeconds) : '0d 0h 0m'}
          icon={Activity}
          loading={statsLoading}
        />
      </div>

      {/* Charts Row */}
      <div className="grid gap-6 md:grid-cols-2">
        {/* Command Usage Chart */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg font-semibold">Top Commands (7 Days)</CardTitle>
          </CardHeader>
          <CardContent>
            {commandsLoading ? (
              <Skeleton className="h-64 w-full" />
            ) : (
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={commandUsage?.slice(0, 8) || []}>
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                  <XAxis 
                    dataKey="name" 
                    stroke="hsl(var(--muted-foreground))"
                    fontSize={12}
                  />
                  <YAxis 
                    stroke="hsl(var(--muted-foreground))"
                    fontSize={12}
                  />
                  <Tooltip 
                    contentStyle={{
                      backgroundColor: 'hsl(var(--popover))',
                      border: '1px solid hsl(var(--border))',
                      borderRadius: '6px',
                    }}
                  />
                  <Bar dataKey="count" fill="hsl(var(--primary))" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            )}
          </CardContent>
        </Card>

        {/* Activity Feed */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg font-semibold">Recent Activity</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {statsLoading ? (
                <>
                  <Skeleton className="h-16 w-full" />
                  <Skeleton className="h-16 w-full" />
                  <Skeleton className="h-16 w-full" />
                </>
              ) : (
                <>
                  <ActivityItem
                    icon={MessageSquare}
                    text="User joined server"
                    server="HELLBORNTV Community"
                    time="2 minutes ago"
                  />
                  <ActivityItem
                    icon={Zap}
                    text="Command executed: /balance"
                    server="Gaming Hub"
                    time="5 minutes ago"
                  />
                  <ActivityItem
                    icon={TrendingUp}
                    text="User reached level 10"
                    server="HELLBORNTV Community"
                    time="12 minutes ago"
                  />
                  <ActivityItem
                    icon={Users}
                    text="New server added"
                    server="Awesome Community"
                    time="1 hour ago"
                  />
                </>
              )}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Additional Stats */}
      <div className="grid gap-6 md:grid-cols-3">
        <Card>
          <CardHeader>
            <CardTitle className="text-sm font-medium text-muted-foreground">Total Commands</CardTitle>
          </CardHeader>
          <CardContent>
            {statsLoading ? (
              <Skeleton className="h-10 w-32" />
            ) : (
              <div className="text-2xl font-bold">{stats?.totalCommands?.toLocaleString() || '0'}</div>
            )}
            <p className="text-xs text-muted-foreground mt-2">All-time executions</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-sm font-medium text-muted-foreground">Messages Processed</CardTitle>
          </CardHeader>
          <CardContent>
            {statsLoading ? (
              <Skeleton className="h-10 w-32" />
            ) : (
              <div className="text-2xl font-bold">{stats?.messagesProcessed?.toLocaleString() || '0'}</div>
            )}
            <p className="text-xs text-muted-foreground mt-2">XP & level tracking</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-sm font-medium text-muted-foreground">Average Response</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">142ms</div>
            <p className="text-xs text-muted-foreground mt-2">Bot latency</p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

function ActivityItem({ icon: Icon, text, server, time }: any) {
  return (
    <div className="flex items-start gap-3 p-3 rounded-md hover-elevate transition-all">
      <div className="rounded-full bg-primary/10 p-2">
        <Icon className="h-4 w-4 text-primary" />
      </div>
      <div className="flex-1 space-y-1">
        <p className="text-sm font-medium">{text}</p>
        <p className="text-xs text-muted-foreground">{server}</p>
      </div>
      <span className="text-xs text-muted-foreground">{time}</span>
    </div>
  );
}
