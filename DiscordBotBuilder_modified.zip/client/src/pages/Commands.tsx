import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Search, DollarSign, Gamepad2, Shield, Smile, Star, TrendingUp } from "lucide-react";
import { useState } from "react";
import { Skeleton } from "@/components/ui/skeleton";

interface Command {
  name: string;
  description: string;
  category: string;
  usageCount: number;
  enabled: boolean;
}

export default function Commands() {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("all");

  const { data: commands, isLoading } = useQuery<Command[]>({
    queryKey: ['/api/bot/commands'],
  });

  const categories = [
    { id: 'all', label: 'All Commands', icon: Star },
    { id: 'economy', label: 'Economy', icon: DollarSign },
    { id: 'games', label: 'Games', icon: Gamepad2 },
    { id: 'moderation', label: 'Moderation', icon: Shield },
    { id: 'fun', label: 'Fun', icon: Smile },
    { id: 'social', label: 'Social', icon: TrendingUp },
  ];

  const filteredCommands = commands?.filter(cmd => {
    const matchesSearch = cmd.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         cmd.description.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = selectedCategory === 'all' || cmd.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const getCategoryColor = (category: string) => {
    const colors: Record<string, string> = {
      economy: 'bg-chart-3/10 text-chart-3 border-chart-3/20',
      games: 'bg-chart-1/10 text-chart-1 border-chart-1/20',
      moderation: 'bg-chart-4/10 text-chart-4 border-chart-4/20',
      fun: 'bg-chart-5/10 text-chart-5 border-chart-5/20',
      social: 'bg-chart-2/10 text-chart-2 border-chart-2/20',
    };
    return colors[category] || 'bg-muted text-muted-foreground';
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold" data-testid="text-commands-title">Command Management</h1>
        <p className="text-muted-foreground mt-1">View and manage all bot slash commands</p>
      </div>

      {/* Search */}
      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        <Input
          placeholder="Search commands..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="pl-9"
          data-testid="input-search-commands"
        />
      </div>

      {/* Category Tabs */}
      <Tabs value={selectedCategory} onValueChange={setSelectedCategory}>
        <TabsList className="grid w-full grid-cols-6 lg:w-auto lg:inline-grid">
          {categories.map(cat => {
            const Icon = cat.icon;
            return (
              <TabsTrigger key={cat.id} value={cat.id} data-testid={`tab-${cat.id}`}>
                <Icon className="h-4 w-4 mr-2 hidden sm:inline" />
                {cat.label}
              </TabsTrigger>
            );
          })}
        </TabsList>

        <TabsContent value={selectedCategory} className="mt-6">
          {isLoading ? (
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
              {[...Array(6)].map((_, i) => (
                <Skeleton key={i} className="h-40" />
              ))}
            </div>
          ) : (
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
              {filteredCommands?.map((command) => (
                <Card key={command.name} className="hover-elevate transition-all" data-testid={`card-command-${command.name}`}>
                  <CardHeader>
                    <div className="flex items-start justify-between gap-2">
                      <div className="flex-1">
                        <CardTitle className="text-lg">/{command.name}</CardTitle>
                        <CardDescription className="mt-1">{command.description}</CardDescription>
                      </div>
                      <Badge 
                        variant="outline" 
                        className={getCategoryColor(command.category)}
                      >
                        {command.category}
                      </Badge>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-muted-foreground">
                        {command.usageCount.toLocaleString()} uses
                      </span>
                      <Badge variant={command.enabled ? "default" : "secondary"}>
                        {command.enabled ? 'Enabled' : 'Disabled'}
                      </Badge>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}

          {!isLoading && filteredCommands?.length === 0 && (
            <Card className="p-12">
              <div className="text-center space-y-2">
                <Search className="h-12 w-12 mx-auto text-muted-foreground opacity-50" />
                <h3 className="text-lg font-semibold">No commands found</h3>
                <p className="text-sm text-muted-foreground">Try adjusting your search or filters</p>
              </div>
            </Card>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}
