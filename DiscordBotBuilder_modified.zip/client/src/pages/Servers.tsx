import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Search, Users, MessageSquare, Settings } from "lucide-react";
import { useState } from "react";
import { Skeleton } from "@/components/ui/skeleton";
import { Button } from "@/components/ui/button";

interface Server {
  id: string;
  name: string;
  icon: string | null;
  memberCount: number;
  commandsUsed: number;
  economyEnabled: boolean;
  levelsEnabled: boolean;
  moderationEnabled: boolean;
}

export default function Servers() {
  const [searchQuery, setSearchQuery] = useState("");

  const { data: servers, isLoading } = useQuery<Server[]>({
    queryKey: ['/api/bot/servers'],
  });

  const filteredServers = servers?.filter(server =>
    server.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold" data-testid="text-servers-title">Servers</h1>
          <p className="text-muted-foreground mt-1">Manage servers where bot is active</p>
        </div>
        <Badge variant="outline" className="text-lg px-4 py-2">
          {servers?.length || 0} Servers
        </Badge>
      </div>

      {/* Search */}
      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        <Input
          placeholder="Search servers..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="pl-9"
          data-testid="input-search-servers"
        />
      </div>

      {/* Servers Grid */}
      {isLoading ? (
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {[...Array(6)].map((_, i) => (
            <Skeleton key={i} className="h-48" />
          ))}
        </div>
      ) : (
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {filteredServers?.map((server) => (
            <Card key={server.id} className="hover-elevate transition-all" data-testid={`card-server-${server.id}`}>
              <CardHeader className="pb-3">
                <div className="flex items-center gap-3">
                  {server.icon ? (
                    <img 
                      src={`https://cdn.discordapp.com/icons/${server.id}/${server.icon}.png`}
                      alt={server.name}
                      className="h-12 w-12 rounded-full"
                    />
                  ) : (
                    <div className="h-12 w-12 rounded-full bg-primary/10 flex items-center justify-center">
                      <span className="text-lg font-bold text-primary">
                        {server.name.charAt(0).toUpperCase()}
                      </span>
                    </div>
                  )}
                  <div className="flex-1 min-w-0">
                    <CardTitle className="text-base truncate">{server.name}</CardTitle>
                    <p className="text-xs text-muted-foreground mt-1">ID: {server.id}</p>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                {/* Stats */}
                <div className="grid grid-cols-2 gap-3">
                  <div className="flex items-center gap-2 text-sm">
                    <Users className="h-4 w-4 text-muted-foreground" />
                    <span>{server.memberCount.toLocaleString()}</span>
                  </div>
                  <div className="flex items-center gap-2 text-sm">
                    <MessageSquare className="h-4 w-4 text-muted-foreground" />
                    <span>{server.commandsUsed.toLocaleString()}</span>
                  </div>
                </div>

                {/* Features */}
                <div className="flex flex-wrap gap-2">
                  {server.economyEnabled && (
                    <Badge variant="secondary" className="text-xs">Economy</Badge>
                  )}
                  {server.levelsEnabled && (
                    <Badge variant="secondary" className="text-xs">Levels</Badge>
                  )}
                  {server.moderationEnabled && (
                    <Badge variant="secondary" className="text-xs">Moderation</Badge>
                  )}
                </div>

                {/* Actions */}
                <Button variant="outline" size="sm" className="w-full" data-testid={`button-settings-${server.id}`}>
                  <Settings className="h-4 w-4 mr-2" />
                  Settings
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {!isLoading && filteredServers?.length === 0 && (
        <Card className="p-12">
          <div className="text-center space-y-2">
            <Search className="h-12 w-12 mx-auto text-muted-foreground opacity-50" />
            <h3 className="text-lg font-semibold">No servers found</h3>
            <p className="text-sm text-muted-foreground">Try adjusting your search</p>
          </div>
        </Card>
      )}
    </div>
  );
}
