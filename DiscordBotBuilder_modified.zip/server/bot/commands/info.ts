import { SlashCommandBuilder, ChatInputCommandInteraction, EmbedBuilder } from 'discord.js';
import { IStorage } from '../../storage';

const HELLBORNTV_LINKS = {
  youtube: 'https://youtube.com/@HELLBORNTV',
  kick: 'https://kick.com/hellborntv',
  instagram: 'https://instagram.com/hellborntv',
  discord: 'https://discord.gg/hellborntv',
};

export const aboutCommand = {
  data: new SlashCommandBuilder()
    .setName('about')
    .setDescription('Information about HELLBORNTV'),
  async execute(interaction: ChatInputCommandInteraction, storage: IStorage) {
    const embed = new EmbedBuilder()
      .setColor(0xFF0000)
      .setTitle('🔥 HELLBORNTV')
      .setDescription('Follow us and join our community!')
      .addFields(
        { name: '📺 YouTube', value: `[HELLBORNTV YouTube](${HELLBORNTV_LINKS.youtube})` },
        { name: '🎮 Kick', value: `[HELLBORNTV Kick](${HELLBORNTV_LINKS.kick})` },
        { name: '📸 Instagram', value: `[HELLBORNTV Instagram](${HELLBORNTV_LINKS.instagram})` },
        { name: '💬 Discord', value: `[Discord Server](${HELLBORNTV_LINKS.discord})` }
      )
      .setFooter({ text: 'HELLBORNTV - We\'re waiting for you!' })
      .setTimestamp();

    await interaction.reply({ embeds: [embed] });
  },
};

export const sponsorCommand = {
  data: new SlashCommandBuilder()
    .setName('sponsor')
    .setDescription('View our sponsors'),
  async execute(interaction: ChatInputCommandInteraction, storage: IStorage) {
    const embed = new EmbedBuilder()
      .setColor(0xFFD700)
      .setTitle('🌟 HELLBORNTV Sponsors')
      .setDescription('Thank you to our amazing sponsors!')
      .addFields({
        name: '🎯 Gecepin',
        value: '**Register now and start winning!**\n\n[📱 Join Now](https://gecepin.com/hesap?ref_code=YHK662Jpxo)',
      })
      .setFooter({ text: 'Interested in sponsoring? Contact us!' })
      .setTimestamp();

    await interaction.reply({ embeds: [embed] });
  },
};

export const helpCommand = {
  data: new SlashCommandBuilder()
    .setName('help')
    .setDescription('View all available commands'),
  async execute(interaction: ChatInputCommandInteraction, storage: IStorage) {
    const embed = new EmbedBuilder()
      .setColor(0x5865F2)
      .setTitle('📚 HELLBORNTV Bot Commands')
      .setDescription('All slash commands available:')
      .addFields(
        {
          name: '💰 Economy',
          value: '`/balance` `/daily` `/weekly` `/pay` `/leaderboard`',
        },
        {
          name: '🎮 Games',
          value: '`/blackjack` `/coinflip` `/dice` `/trivia`',
        },
        {
          name: '🛡️ Moderation',
          value: '`/kick` `/ban` `/timeout` `/warn` `/warnings` `/cleanup`',
        },
        {
          name: '😄 Fun',
          value: '`/meme` `/dog` `/cat` `/8ball`',
        },
        {
          name: '👤 Social',
          value: '`/profile` `/inventory` `/achievements` `/rank`',
        },
        {
          name: 'ℹ️ Info',
          value: '`/about` `/sponsor` `/help`',
        }
      )
      .setFooter({ text: 'HELLBORNTV Discord Bot | Use / to see command details' })
      .setTimestamp();

    await interaction.reply({ embeds: [embed] });
  },
};

// Turkish aliases for some info commands
export const hakkimdaCommand = { ...aboutCommand, data: aboutCommand.data.setName('hakkimda') };
export const premiumCommand = { ...aboutCommand, data: aboutCommand.data.setName('premium') };
