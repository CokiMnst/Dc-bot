import { SlashCommandBuilder, ChatInputCommandInteraction, EmbedBuilder, PermissionFlagsBits } from 'discord.js';
import { IStorage } from '../../storage';

export const kickCommand = {
  data: new SlashCommandBuilder()
    .setName('kick')
    .setDescription('Kick a member from the server')
    .addUserOption(option =>
      option.setName('user')
        .setDescription('The user to kick')
        .setRequired(true)
    )
    .addStringOption(option =>
      option.setName('reason')
        .setDescription('Reason for kicking')
        .setRequired(false)
    )
    .setDefaultMemberPermissions(PermissionFlagsBits.KickMembers),
  async execute(interaction: ChatInputCommandInteraction, storage: IStorage) {
    if (!interaction.guild) return;

    const target = interaction.options.getUser('user', true);
    const reason = interaction.options.getString('reason') || 'No reason provided';
    const member = interaction.guild.members.cache.get(target.id);

    if (!member) {
      return interaction.reply({ content: '❌ User not found in this server!', ephemeral: true });
    }

    if (!member.kickable) {
      return interaction.reply({ content: '❌ I cannot kick this user!', ephemeral: true });
    }

    await member.kick(reason);

    const embed = new EmbedBuilder()
      .setColor(0xFEE75C)
      .setTitle('👢 Member Kicked')
      .setDescription(`**${target.username}** has been kicked`)
      .addFields(
        { name: 'Reason', value: reason },
        { name: 'Moderator', value: interaction.user.username }
      )
      .setTimestamp();

    await interaction.reply({ embeds: [embed] });
  },
};

export const banCommand = {
  data: new SlashCommandBuilder()
    .setName('ban')
    .setDescription('Ban a member from the server')
    .addUserOption(option =>
      option.setName('user')
        .setDescription('The user to ban')
        .setRequired(true)
    )
    .addStringOption(option =>
      option.setName('reason')
        .setDescription('Reason for banning')
        .setRequired(false)
    )
    .setDefaultMemberPermissions(PermissionFlagsBits.BanMembers),
  async execute(interaction: ChatInputCommandInteraction, storage: IStorage) {
    if (!interaction.guild) return;

    const target = interaction.options.getUser('user', true);
    const reason = interaction.options.getString('reason') || 'No reason provided';
    const member = interaction.guild.members.cache.get(target.id);

    if (member && !member.bannable) {
      return interaction.reply({ content: '❌ I cannot ban this user!', ephemeral: true });
    }

    await interaction.guild.members.ban(target.id, { reason });

    const embed = new EmbedBuilder()
      .setColor(0xED4245)
      .setTitle('🔨 Member Banned')
      .setDescription(`**${target.username}** has been banned`)
      .addFields(
        { name: 'Reason', value: reason },
        { name: 'Moderator', value: interaction.user.username }
      )
      .setTimestamp();

    await interaction.reply({ embeds: [embed] });
  },
};

export const timeoutCommand = {
  data: new SlashCommandBuilder()
    .setName('timeout')
    .setDescription('Timeout a member')
    .addUserOption(option =>
      option.setName('user')
        .setDescription('The user to timeout')
        .setRequired(true)
    )
    .addIntegerOption(option =>
      option.setName('duration')
        .setDescription('Duration in minutes')
        .setRequired(true)
        .setMinValue(1)
        .setMaxValue(1440)
    )
    .addStringOption(option =>
      option.setName('reason')
        .setDescription('Reason for timeout')
        .setRequired(false)
    )
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers),
  async execute(interaction: ChatInputCommandInteraction, storage: IStorage) {
    if (!interaction.guild) return;

    const target = interaction.options.getUser('user', true);
    const duration = interaction.options.getInteger('duration', true);
    const reason = interaction.options.getString('reason') || 'No reason provided';
    const member = interaction.guild.members.cache.get(target.id);

    if (!member) {
      return interaction.reply({ content: '❌ User not found in this server!', ephemeral: true });
    }

    if (!member.moderatable) {
      return interaction.reply({ content: '❌ I cannot timeout this user!', ephemeral: true });
    }

    await member.timeout(duration * 60 * 1000, reason);

    const embed = new EmbedBuilder()
      .setColor(0xFEE75C)
      .setTitle('⏰ Member Timed Out')
      .setDescription(`**${target.username}** has been timed out`)
      .addFields(
        { name: 'Duration', value: `${duration} minutes` },
        { name: 'Reason', value: reason },
        { name: 'Moderator', value: interaction.user.username }
      )
      .setTimestamp();

    await interaction.reply({ embeds: [embed] });
  },
};

export const warnCommand = {
  data: new SlashCommandBuilder()
    .setName('warn')
    .setDescription('Warn a member')
    .addUserOption(option =>
      option.setName('user')
        .setDescription('The user to warn')
        .setRequired(true)
    )
    .addStringOption(option =>
      option.setName('reason')
        .setDescription('Reason for warning')
        .setRequired(true)
    )
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers),
  async execute(interaction: ChatInputCommandInteraction, storage: IStorage) {
    if (!interaction.guild) return;

    const target = interaction.options.getUser('user', true);
    const reason = interaction.options.getString('reason', true);

    await storage.addWarning({
      guildId: interaction.guild.id,
      userId: target.id,
      moderatorId: interaction.user.id,
      reason,
    });

    const warnings = await storage.getUserWarnings(interaction.guild.id, target.id);

    const embed = new EmbedBuilder()
      .setColor(0xFEE75C)
      .setTitle('⚠️ Member Warned')
      .setDescription(`**${target.username}** has been warned`)
      .addFields(
        { name: 'Reason', value: reason },
        { name: 'Total Warnings', value: `${warnings.length}` },
        { name: 'Moderator', value: interaction.user.username }
      )
      .setTimestamp();

    await interaction.reply({ embeds: [embed] });
  },
};

export const warningsCommand = {
  data: new SlashCommandBuilder()
    .setName('warnings')
    .setDescription('View warnings for a user')
    .addUserOption(option =>
      option.setName('user')
        .setDescription('The user to check')
        .setRequired(false)
    ),
  async execute(interaction: ChatInputCommandInteraction, storage: IStorage) {
    if (!interaction.guild) return;

    const target = interaction.options.getUser('user') || interaction.user;
    const warnings = await storage.getUserWarnings(interaction.guild.id, target.id);

    if (warnings.length === 0) {
      return interaction.reply({
        content: `✅ ${target.username} has no warnings!`,
        ephemeral: true,
      });
    }

    const embed = new EmbedBuilder()
      .setColor(0xFEE75C)
      .setTitle(`⚠️ Warnings for ${target.username}`)
      .setDescription(
        warnings.slice(0, 5).map((w, i) =>
          `**${i + 1}.** ${w.reason}\n*<t:${Math.floor(new Date(w.createdAt).getTime() / 1000)}:R>*`
        ).join('\n\n')
      )
      .setFooter({ text: `Total: ${warnings.length} warning(s)` })
      .setTimestamp();

    await interaction.reply({ embeds: [embed] });
  },
};

export const cleanupCommand = {
  data: new SlashCommandBuilder()
    .setName('cleanup')
    .setDescription('Delete multiple messages')
    .addIntegerOption(option =>
      option.setName('amount')
        .setDescription('Number of messages to delete (1-100)')
        .setRequired(true)
        .setMinValue(1)
        .setMaxValue(100)
    )
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages),
  async execute(interaction: ChatInputCommandInteraction, storage: IStorage) {
    if (!interaction.channel || !interaction.channel.isTextBased()) return;

    const amount = interaction.options.getInteger('amount', true);

    await interaction.deferReply({ ephemeral: true });

    const messages = await interaction.channel.messages.fetch({ limit: amount });
    const deleted = await interaction.channel.bulkDelete(messages, true);

    await interaction.editReply(`✅ Deleted **${deleted.size}** messages!`);
  },
};
