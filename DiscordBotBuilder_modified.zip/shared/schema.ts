import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, timestamp, boolean, jsonb } from "drizzle-orm/pg-core";
import { relations } from "drizzle-orm";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Users table - stores Discord user data, economy, levels
export const users = pgTable("users", {
  id: varchar("id").primaryKey(), // Discord user ID
  username: text("username").notNull(),
  discriminator: text("discriminator"),
  avatar: text("avatar"),
  
  // Economy system
  balance: integer("balance").notNull().default(0),
  bank: integer("bank").notNull().default(0),
  lastDaily: timestamp("last_daily"),
  lastWeekly: timestamp("last_weekly"),
  
  // Level/XP system
  xp: integer("xp").notNull().default(0),
  level: integer("level").notNull().default(1),
  totalMessages: integer("total_messages").notNull().default(0),
  
  // Stats
  createdAt: timestamp("created_at").notNull().defaultNow(),
  lastSeen: timestamp("last_seen").notNull().defaultNow(),
});

// Guilds (servers) table
export const guilds = pgTable("guilds", {
  id: varchar("id").primaryKey(), // Discord guild ID
  name: text("name").notNull(),
  icon: text("icon"),
  
  // Bot configuration
  prefix: text("prefix").default("!"),
  welcomeChannelId: varchar("welcome_channel_id"),
  welcomeMessage: text("welcome_message"),
  levelUpChannelId: varchar("level_up_channel_id"),
  moderationLogChannelId: varchar("moderation_log_channel_id"),
  
  // Feature toggles
  economyEnabled: boolean("economy_enabled").notNull().default(true),
  levelsEnabled: boolean("levels_enabled").notNull().default(true),
  moderationEnabled: boolean("moderation_enabled").notNull().default(true),
  
  // Stats
  memberCount: integer("member_count").notNull().default(0),
  botJoinedAt: timestamp("bot_joined_at").notNull().defaultNow(),
});

// Inventory items
export const inventory = pgTable("inventory", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id, { onDelete: 'cascade' }),
  itemName: text("item_name").notNull(),
  itemType: text("item_type").notNull(), // 'collectible', 'tool', 'badge'
  quantity: integer("quantity").notNull().default(1),
  acquiredAt: timestamp("acquired_at").notNull().defaultNow(),
});

// Achievements
export const achievements = pgTable("achievements", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id, { onDelete: 'cascade' }),
  achievementId: text("achievement_id").notNull(), // 'first_message', 'level_10', 'rich_100k'
  unlockedAt: timestamp("unlocked_at").notNull().defaultNow(),
});

// Moderation warnings
export const warnings = pgTable("warnings", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  guildId: varchar("guild_id").notNull().references(() => guilds.id, { onDelete: 'cascade' }),
  userId: varchar("user_id").notNull(),
  moderatorId: varchar("moderator_id").notNull(),
  reason: text("reason").notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

// Command usage statistics
export const commandStats = pgTable("command_stats", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  commandName: text("command_name").notNull(),
  guildId: varchar("guild_id"),
  userId: varchar("user_id"),
  executedAt: timestamp("executed_at").notNull().defaultNow(),
  success: boolean("success").notNull().default(true),
});

// Trivia questions
export const triviaQuestions = pgTable("trivia_questions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  question: text("question").notNull(),
  correctAnswer: text("correct_answer").notNull(),
  wrongAnswers: text("wrong_answers").array().notNull(),
  category: text("category").notNull(),
  difficulty: text("difficulty").notNull(), // 'easy', 'medium', 'hard'
});

// Trivia scores
export const triviaScores = pgTable("trivia_scores", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id, { onDelete: 'cascade' }),
  correct: integer("correct").notNull().default(0),
  wrong: integer("wrong").notNull().default(0),
  streak: integer("streak").notNull().default(0),
});

// Relations
export const usersRelations = relations(users, ({ many }) => ({
  inventory: many(inventory),
  achievements: many(achievements),
  triviaScores: many(triviaScores),
}));

export const guildsRelations = relations(guilds, ({ many }) => ({
  warnings: many(warnings),
}));

export const inventoryRelations = relations(inventory, ({ one }) => ({
  user: one(users, {
    fields: [inventory.userId],
    references: [users.id],
  }),
}));

export const achievementsRelations = relations(achievements, ({ one }) => ({
  user: one(users, {
    fields: [achievements.userId],
    references: [users.id],
  }),
}));

export const warningsRelations = relations(warnings, ({ one }) => ({
  guild: one(guilds, {
    fields: [warnings.guildId],
    references: [guilds.id],
  }),
}));

export const triviaScoresRelations = relations(triviaScores, ({ one }) => ({
  user: one(users, {
    fields: [triviaScores.userId],
    references: [users.id],
  }),
}));

// Insert schemas
export const insertUserSchema = createInsertSchema(users).omit({
  createdAt: true,
  lastSeen: true,
});

export const insertGuildSchema = createInsertSchema(guilds).omit({
  botJoinedAt: true,
});

export const insertInventorySchema = createInsertSchema(inventory).omit({
  id: true,
  acquiredAt: true,
});

export const insertAchievementSchema = createInsertSchema(achievements).omit({
  id: true,
  unlockedAt: true,
});

export const insertWarningSchema = createInsertSchema(warnings).omit({
  id: true,
  createdAt: true,
});

export const insertCommandStatSchema = createInsertSchema(commandStats).omit({
  id: true,
  executedAt: true,
});

export const insertTriviaQuestionSchema = createInsertSchema(triviaQuestions).omit({
  id: true,
});

export const insertTriviaScoreSchema = createInsertSchema(triviaScores).omit({
  id: true,
});

// Types
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

export type Guild = typeof guilds.$inferSelect;
export type InsertGuild = z.infer<typeof insertGuildSchema>;

export type Inventory = typeof inventory.$inferSelect;
export type InsertInventory = z.infer<typeof insertInventorySchema>;

export type Achievement = typeof achievements.$inferSelect;
export type InsertAchievement = z.infer<typeof insertAchievementSchema>;

export type Warning = typeof warnings.$inferSelect;
export type InsertWarning = z.infer<typeof insertWarningSchema>;

export type CommandStat = typeof commandStats.$inferSelect;
export type InsertCommandStat = z.infer<typeof insertCommandStatSchema>;

export type TriviaQuestion = typeof triviaQuestions.$inferSelect;
export type InsertTriviaQuestion = z.infer<typeof insertTriviaQuestionSchema>;

export type TriviaScore = typeof triviaScores.$inferSelect;
export type InsertTriviaScore = z.infer<typeof insertTriviaScoreSchema>;
