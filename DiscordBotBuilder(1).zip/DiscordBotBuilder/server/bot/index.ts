import { Client, GatewayIntentBits, Events, REST, Routes, Collection } from 'discord.js';
import { storage } from '../storage';

// Import command handlers
import { balanceCommand, dailyCommand, weeklyCommand, payCommand, leaderboardCommand } from './commands/economy';
import { blackjackCommand, coinflipCommand, diceCommand, triviaCommand } from './commands/games';
import { kickCommand, banCommand, timeoutCommand, warnCommand, warningsCommand, cleanupCommand } from './commands/moderation';
import { memeCommand, dogCommand, catCommand, eightballCommand } from './commands/fun';
import { profileCommand, inventoryCommand, achievementsCommand, rankCommand } from './commands/social';
import { aboutCommand, sponsorCommand, helpCommand } from './commands/info';

// Bot state
export let botClient: Client | null = null;
export let botStats = {
  startTime: Date.now(),
  commandsExecuted: 0,
  messagesProcessed: 0,
};

const commands = [
  // Economy
  balanceCommand,
  dailyCommand,
  weeklyCommand,
  payCommand,
  leaderboardCommand,
  // Games
  blackjackCommand,
  coinflipCommand,
  diceCommand,
  triviaCommand,
  // Moderation
  kickCommand,
  banCommand,
  timeoutCommand,
  warnCommand,
  warningsCommand,
  cleanupCommand,
  // Fun
  memeCommand,
  dogCommand,
  catCommand,
  eightballCommand,
  // Social
  profileCommand,
  inventoryCommand,
  achievementsCommand,
  rankCommand,
  // Info
  aboutCommand,
  sponsorCommand,
  helpCommand,
];

export async function startBot() {
  const BOT_TOKEN = process.env.BOT_TOKEN;
  const CLIENT_ID = process.env.CLIENT_ID;
  const GUILD_ID = process.env.GUILD_ID;

  if (!BOT_TOKEN || !CLIENT_ID) {
    console.error('❌ BOT_TOKEN and CLIENT_ID are required!');
    return;
  }

  // Create Discord client
  const client = new Client({
    intents: [
      GatewayIntentBits.Guilds,
      GatewayIntentBits.GuildMessages,
      GatewayIntentBits.MessageContent,
      GatewayIntentBits.GuildMembers,
      GatewayIntentBits.GuildVoiceStates,
    ],
  });

  botClient = client;

  // Register slash commands
  const rest = new REST({ version: '10' }).setToken(BOT_TOKEN);

  try {
    console.log('🔄 Registering slash commands...');

    const commandData = commands.map(cmd => cmd.data.toJSON());

    // Register commands globally or to specific guild
    if (GUILD_ID) {
      await rest.put(
        Routes.applicationGuildCommands(CLIENT_ID, GUILD_ID),
        { body: commandData },
      );
      console.log(`✅ Registered ${commandData.length} commands to guild ${GUILD_ID}`);
    } else {
      await rest.put(
        Routes.applicationCommands(CLIENT_ID),
        { body: commandData },
      );
      console.log(`✅ Registered ${commandData.length} commands globally`);
    }
  } catch (error) {
    console.error('❌ Error registering commands:', error);
  }

  // Ready event
  client.once(Events.ClientReady, async (c) => {
    console.log(`✅ Bot ready! Logged in as ${c.user.tag}`);
    console.log(`📊 Serving ${c.guilds.cache.size} servers`);

    // Set bot status
    const statuses = [
      { name: 'HELLBORNTV 🔥', type: 2 },
      { name: '/help for commands 📚', type: 2 },
      { name: `${c.guilds.cache.size} servers 🎮`, type: 3 },
    ];

    let i = 0;
    setInterval(() => {
      c.user.setActivity(statuses[i].name, { type: statuses[i].type });
      i = (i + 1) % statuses.length;
    }, 15000);

    // Sync guilds to database
    for (const [guildId, guild] of c.guilds.cache) {
      await storage.createGuild({
        id: guildId,
        name: guild.name,
        icon: guild.icon,
        memberCount: guild.memberCount,
      });
    }
  });

  // Interaction (slash command) handler
  client.on(Events.InteractionCreate, async (interaction) => {
    if (!interaction.isChatInputCommand()) return;

    const command = commands.find(cmd => cmd.data.name === interaction.commandName);
    if (!command) return;

    try {
      await command.execute(interaction, storage);
      botStats.commandsExecuted++;
      
      // Log command usage
      await storage.logCommandUsage({
        commandName: interaction.commandName,
        guildId: interaction.guildId,
        userId: interaction.user.id,
        success: true,
      });
    } catch (error) {
      console.error(`Error executing command ${interaction.commandName}:`, error);
      
      await storage.logCommandUsage({
        commandName: interaction.commandName,
        guildId: interaction.guildId,
        userId: interaction.user.id,
        success: false,
      });

      if (interaction.deferred || interaction.replied) {
        await interaction.followUp({ content: '❌ An error occurred!', ephemeral: true });
      } else {
        await interaction.reply({ content: '❌ An error occurred!', ephemeral: true });
      }
    }
  });

  // Message handler for XP system
  client.on(Events.MessageCreate, async (message) => {
    if (message.author.bot) return;
    if (!message.guild) return;

    botStats.messagesProcessed++;

    // Ensure user exists in database
    const user = await storage.getUser(message.author.id);
    if (!user) {
      await storage.createUser({
        id: message.author.id,
        username: message.author.username,
        discriminator: message.author.discriminator,
        avatar: message.author.avatar,
      });
    }

    // Add XP (random 15-25 XP per message, cooldown handled by rate limiting)
    const xpGain = Math.floor(Math.random() * 11) + 15; // 15-25 XP
    const currentUser = await storage.getUser(message.author.id);
    if (!currentUser) return;

    const newXP = currentUser.xp + xpGain;
    const newLevel = Math.floor(newXP / 100) + 1; // Simple level formula: 100 XP per level

    // Check if level up
    if (newLevel > currentUser.level) {
      await storage.updateUserXP(message.author.id, newXP, newLevel);
      
      message.reply(`🎉 Congratulations! You've reached level **${newLevel}**!`);
      
      // Award achievement for level milestones
      if (newLevel === 10) {
        await storage.addAchievement({
          userId: message.author.id,
          achievementId: 'level_10',
        });
      }
    } else {
      await storage.updateUserXP(message.author.id, newXP, currentUser.level);
    }
  });

  // Guild join event
  client.on(Events.GuildCreate, async (guild) => {
    console.log(`➕ Joined new guild: ${guild.name} (${guild.id})`);
    
    await storage.createGuild({
      id: guild.id,
      name: guild.name,
      icon: guild.icon,
      memberCount: guild.memberCount,
    });
  });

  // Guild member add event (welcome message)
  client.on(Events.GuildMemberAdd, async (member) => {
    const guild = await storage.getGuild(member.guild.id);
    if (!guild || !guild.welcomeChannelId || !guild.welcomeMessage) return;

    const channel = member.guild.channels.cache.get(guild.welcomeChannelId);
    if (!channel || !channel.isTextBased()) return;

    const welcomeMsg = guild.welcomeMessage
      .replace('{user}', `<@${member.id}>`)
      .replace('{server}', member.guild.name);

    await channel.send(welcomeMsg);
  });

  // Login
  await client.login(BOT_TOKEN);
}

export function getBotClient() {
  return botClient;
}

export function getBotStats() {
  return {
    ...botStats,
    uptime: Math.floor((Date.now() - botStats.startTime) / 1000),
  };
}
