import { SlashCommandBuilder, ChatInputCommandInteraction, EmbedBuilder } from 'discord.js';
import { IStorage } from '../../storage';

const memes = [
  'https://i.imgur.com/random1.jpg',
  'This is where I\'d put my meme... IF I HAD ONE!',
  '404: Meme not found... Just kidding! 😄',
];

const funResponses = [
  'OwO what\'s this?',
  'UwU *notices your command*',
  '*nuzzles* henwo!',
  'Rawr! XD',
  '*pounces* hewwo there!',
];

export const memeCommand = {
  data: new SlashCommandBuilder()
    .setName('meme')
    .setDescription('Get a random meme'),
  async execute(interaction: ChatInputCommandInteraction, storage: IStorage) {
    const randomMeme = memes[Math.floor(Math.random() * memes.length)];

    const embed = new EmbedBuilder()
      .setColor(0x5865F2)
      .setTitle('😂 Random Meme')
      .setDescription(randomMeme.startsWith('http') ? null : randomMeme)
      .setImage(randomMeme.startsWith('http') ? randomMeme : null)
      .setTimestamp();

    await interaction.reply({ embeds: [embed] });
  },
};

export const dogCommand = {
  data: new SlashCommandBuilder()
    .setName('dog')
    .setDescription('Get a random dog picture'),
  async execute(interaction: ChatInputCommandInteraction, storage: IStorage) {
    await interaction.deferReply();

    try {
      const response = await fetch('https://dog.ceo/api/breeds/image/random');
      const data = await response.json();

      const embed = new EmbedBuilder()
        .setColor(0x5865F2)
        .setTitle('🐕 Random Dog')
        .setImage(data.message)
        .setTimestamp();

      await interaction.editReply({ embeds: [embed] });
    } catch (error) {
      await interaction.editReply('❌ Failed to fetch dog picture!');
    }
  },
};

export const catCommand = {
  data: new SlashCommandBuilder()
    .setName('cat')
    .setDescription('Get a random cat picture'),
  async execute(interaction: ChatInputCommandInteraction, storage: IStorage) {
    await interaction.deferReply();

    try {
      const response = await fetch('https://api.thecatapi.com/v1/images/search');
      const data = await response.json();

      const embed = new EmbedBuilder()
        .setColor(0x5865F2)
        .setTitle('🐱 Random Cat')
        .setImage(data[0].url)
        .setTimestamp();

      await interaction.editReply({ embeds: [embed] });
    } catch (error) {
      await interaction.editReply('❌ Failed to fetch cat picture!');
    }
  },
};

export const eightballCommand = {
  data: new SlashCommandBuilder()
    .setName('8ball')
    .setDescription('Ask the magic 8ball a question')
    .addStringOption(option =>
      option.setName('question')
        .setDescription('Your question')
        .setRequired(true)
    ),
  async execute(interaction: ChatInputCommandInteraction, storage: IStorage) {
    const question = interaction.options.getString('question', true);

    const responses = [
      'Yes, definitely!',
      'It is certain.',
      'Without a doubt.',
      'Most likely.',
      'Outlook good.',
      'Maybe...',
      'Ask again later.',
      'Cannot predict now.',
      'Don\'t count on it.',
      'My sources say no.',
      'Very doubtful.',
      'Absolutely not!',
    ];

    const answer = responses[Math.floor(Math.random() * responses.length)];

    const embed = new EmbedBuilder()
      .setColor(0x5865F2)
      .setTitle('🎱 Magic 8Ball')
      .addFields(
        { name: 'Question', value: question },
        { name: 'Answer', value: answer }
      )
      .setTimestamp();

    await interaction.reply({ embeds: [embed] });
  },
};
