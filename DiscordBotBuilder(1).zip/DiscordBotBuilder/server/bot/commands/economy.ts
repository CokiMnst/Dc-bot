import { SlashCommandBuilder, ChatInputCommandInteraction, EmbedBuilder } from 'discord.js';
import { IStorage } from '../../storage';

export const balanceCommand = {
  data: new SlashCommandBuilder()
    .setName('balance')
    .setDescription('Check your balance or someone else\'s')
    .addUserOption(option =>
      option.setName('user')
        .setDescription('The user to check')
        .setRequired(false)
    ),
  async execute(interaction: ChatInputCommandInteraction, storage: IStorage) {
    const targetUser = interaction.options.getUser('user') || interaction.user;
    
    let user = await storage.getUser(targetUser.id);
    if (!user) {
      user = await storage.createUser({
        id: targetUser.id,
        username: targetUser.username,
        discriminator: targetUser.discriminator,
        avatar: targetUser.avatar,
      });
    }

    const embed = new EmbedBuilder()
      .setColor(0x5865F2)
      .setTitle(`💰 ${targetUser.username}'s Balance`)
      .addFields(
        { name: 'Wallet', value: `${user.balance.toLocaleString()} coins`, inline: true },
        { name: 'Bank', value: `${user.bank.toLocaleString()} coins`, inline: true },
        { name: 'Total', value: `${(user.balance + user.bank).toLocaleString()} coins`, inline: true }
      )
      .setThumbnail(targetUser.displayAvatarURL())
      .setTimestamp();

    await interaction.reply({ embeds: [embed] });
  },
};

export const dailyCommand = {
  data: new SlashCommandBuilder()
    .setName('daily')
    .setDescription('Claim your daily reward'),
  async execute(interaction: ChatInputCommandInteraction, storage: IStorage) {
    let user = await storage.getUser(interaction.user.id);
    if (!user) {
      user = await storage.createUser({
        id: interaction.user.id,
        username: interaction.user.username,
        discriminator: interaction.user.discriminator,
        avatar: interaction.user.avatar,
      });
    }

    const now = new Date();
    const lastDaily = user.lastDaily ? new Date(user.lastDaily) : null;
    
    if (lastDaily) {
      const timeSince = now.getTime() - lastDaily.getTime();
      const hoursLeft = 24 - Math.floor(timeSince / (1000 * 60 * 60));
      
      if (timeSince < 24 * 60 * 60 * 1000) {
        return interaction.reply({
          content: `⏰ You've already claimed your daily reward! Come back in **${hoursLeft} hours**.`,
          ephemeral: true,
        });
      }
    }

    const reward = 1000;
    await storage.updateDailyClaim(interaction.user.id, user.balance + reward);
    
    const embed = new EmbedBuilder()
      .setColor(0x57F287)
      .setTitle('🎁 Daily Reward Claimed!')
      .setDescription(`You received **${reward} coins**!`)
      .addFields({ name: 'New Balance', value: `${(user.balance + reward).toLocaleString()} coins` })
      .setTimestamp();

    await interaction.reply({ embeds: [embed] });
  },
};

export const weeklyCommand = {
  data: new SlashCommandBuilder()
    .setName('weekly')
    .setDescription('Claim your weekly reward'),
  async execute(interaction: ChatInputCommandInteraction, storage: IStorage) {
    let user = await storage.getUser(interaction.user.id);
    if (!user) {
      user = await storage.createUser({
        id: interaction.user.id,
        username: interaction.user.username,
        discriminator: interaction.user.discriminator,
        avatar: interaction.user.avatar,
      });
    }

    const now = new Date();
    const lastWeekly = user.lastWeekly ? new Date(user.lastWeekly) : null;
    
    if (lastWeekly) {
      const timeSince = now.getTime() - lastWeekly.getTime();
      const daysLeft = 7 - Math.floor(timeSince / (1000 * 60 * 60 * 24));
      
      if (timeSince < 7 * 24 * 60 * 60 * 1000) {
        return interaction.reply({
          content: `⏰ You've already claimed your weekly reward! Come back in **${daysLeft} days**.`,
          ephemeral: true,
        });
      }
    }

    const reward = 5000;
    await storage.updateWeeklyClaim(interaction.user.id, user.balance + reward);
    
    const embed = new EmbedBuilder()
      .setColor(0x57F287)
      .setTitle('🎁 Weekly Reward Claimed!')
      .setDescription(`You received **${reward} coins**!`)
      .addFields({ name: 'New Balance', value: `${(user.balance + reward).toLocaleString()} coins` })
      .setTimestamp();

    await interaction.reply({ embeds: [embed] });
  },
};

export const payCommand = {
  data: new SlashCommandBuilder()
    .setName('pay')
    .setDescription('Send money to another user')
    .addUserOption(option =>
      option.setName('user')
        .setDescription('The user to send money to')
        .setRequired(true)
    )
    .addIntegerOption(option =>
      option.setName('amount')
        .setDescription('Amount to send')
        .setRequired(true)
        .setMinValue(1)
    ),
  async execute(interaction: ChatInputCommandInteraction, storage: IStorage) {
    const recipient = interaction.options.getUser('user', true);
    const amount = interaction.options.getInteger('amount', true);

    if (recipient.bot) {
      return interaction.reply({ content: '❌ You cannot send money to bots!', ephemeral: true });
    }

    if (recipient.id === interaction.user.id) {
      return interaction.reply({ content: '❌ You cannot send money to yourself!', ephemeral: true });
    }

    let sender = await storage.getUser(interaction.user.id);
    if (!sender) {
      sender = await storage.createUser({
        id: interaction.user.id,
        username: interaction.user.username,
        discriminator: interaction.user.discriminator,
        avatar: interaction.user.avatar,
      });
    }

    if (sender.balance < amount) {
      return interaction.reply({
        content: `❌ You don't have enough coins! You only have **${sender.balance} coins**.`,
        ephemeral: true,
      });
    }

    let recipientUser = await storage.getUser(recipient.id);
    if (!recipientUser) {
      recipientUser = await storage.createUser({
        id: recipient.id,
        username: recipient.username,
        discriminator: recipient.discriminator,
        avatar: recipient.avatar,
      });
    }

    await storage.updateUserBalance(interaction.user.id, sender.balance - amount, sender.bank);
    await storage.updateUserBalance(recipient.id, recipientUser.balance + amount, recipientUser.bank);

    const embed = new EmbedBuilder()
      .setColor(0x57F287)
      .setTitle('💸 Payment Successful')
      .setDescription(`You sent **${amount} coins** to ${recipient.username}`)
      .addFields({ name: 'Your New Balance', value: `${(sender.balance - amount).toLocaleString()} coins` })
      .setTimestamp();

    await interaction.reply({ embeds: [embed] });
  },
};

export const leaderboardCommand = {
  data: new SlashCommandBuilder()
    .setName('leaderboard')
    .setDescription('View the richest users'),
  async execute(interaction: ChatInputCommandInteraction, storage: IStorage) {
    const topUsers = await storage.getUsersLeaderboard(10);

    const embed = new EmbedBuilder()
      .setColor(0xFEE75C)
      .setTitle('🏆 Wealth Leaderboard')
      .setDescription(
        topUsers.map((user, i) => {
          const medals = ['🥇', '🥈', '🥉'];
          const medal = medals[i] || `${i + 1}.`;
          const total = user.balance + user.bank;
          return `${medal} **${user.username}** - ${total.toLocaleString()} coins`;
        }).join('\n')
      )
      .setTimestamp();

    await interaction.reply({ embeds: [embed] });
  },
};
