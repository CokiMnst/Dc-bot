import { SlashCommandBuilder, ChatInputCommandInteraction, EmbedBuilder } from 'discord.js';
import { IStorage } from '../../storage';

export const profileCommand = {
  data: new SlashCommandBuilder()
    .setName('profile')
    .setDescription('View your profile or someone else\'s')
    .addUserOption(option =>
      option.setName('user')
        .setDescription('The user to view')
        .setRequired(false)
    ),
  async execute(interaction: ChatInputCommandInteraction, storage: IStorage) {
    const targetUser = interaction.options.getUser('user') || interaction.user;

    let user = await storage.getUser(targetUser.id);
    if (!user) {
      user = await storage.createUser({
        id: targetUser.id,
        username: targetUser.username,
        discriminator: targetUser.discriminator,
        avatar: targetUser.avatar,
      });
    }

    const achievements = await storage.getUserAchievements(targetUser.id);
    const inventory = await storage.getUserInventory(targetUser.id);

    const xpNeeded = (user.level + 1) * 100;
    const xpProgress = Math.floor((user.xp / xpNeeded) * 100);

    const embed = new EmbedBuilder()
      .setColor(0x5865F2)
      .setTitle(`${targetUser.username}'s Profile`)
      .setThumbnail(targetUser.displayAvatarURL())
      .addFields(
        { name: '💰 Wealth', value: `${(user.balance + user.bank).toLocaleString()} coins`, inline: true },
        { name: '⭐ Level', value: `${user.level}`, inline: true },
        { name: '📊 XP', value: `${user.xp}/${xpNeeded} (${xpProgress}%)`, inline: true },
        { name: '💬 Messages', value: `${user.totalMessages.toLocaleString()}`, inline: true },
        { name: '🎖️ Achievements', value: `${achievements.length}`, inline: true },
        { name: '🎒 Items', value: `${inventory.length}`, inline: true }
      )
      .setTimestamp();

    await interaction.reply({ embeds: [embed] });
  },
};

export const inventoryCommand = {
  data: new SlashCommandBuilder()
    .setName('inventory')
    .setDescription('View your inventory'),
  async execute(interaction: ChatInputCommandInteraction, storage: IStorage) {
    const inventory = await storage.getUserInventory(interaction.user.id);

    if (inventory.length === 0) {
      return interaction.reply({
        content: '🎒 Your inventory is empty!',
        ephemeral: true,
      });
    }

    const embed = new EmbedBuilder()
      .setColor(0x5865F2)
      .setTitle('🎒 Your Inventory')
      .setDescription(
        inventory.map(item =>
          `**${item.itemName}** x${item.quantity} - *${item.itemType}*`
        ).join('\n')
      )
      .setTimestamp();

    await interaction.reply({ embeds: [embed] });
  },
};

export const achievementsCommand = {
  data: new SlashCommandBuilder()
    .setName('achievements')
    .setDescription('View your achievements'),
  async execute(interaction: ChatInputCommandInteraction, storage: IStorage) {
    const achievements = await storage.getUserAchievements(interaction.user.id);

    if (achievements.length === 0) {
      return interaction.reply({
        content: '🎖️ You haven\'t unlocked any achievements yet!',
        ephemeral: true,
      });
    }

    const achievementNames: Record<string, string> = {
      'first_message': '💬 First Message',
      'level_10': '⭐ Level 10',
      'rich_100k': '💰 Wealthy (100k coins)',
    };

    const embed = new EmbedBuilder()
      .setColor(0xFEE75C)
      .setTitle('🎖️ Your Achievements')
      .setDescription(
        achievements.map(a =>
          `${achievementNames[a.achievementId] || a.achievementId}\n*Unlocked <t:${Math.floor(new Date(a.unlockedAt).getTime() / 1000)}:R>*`
        ).join('\n\n')
      )
      .setTimestamp();

    await interaction.reply({ embeds: [embed] });
  },
};

export const rankCommand = {
  data: new SlashCommandBuilder()
    .setName('rank')
    .setDescription('View your rank and level'),
  async execute(interaction: ChatInputCommandInteraction, storage: IStorage) {
    let user = await storage.getUser(interaction.user.id);
    if (!user) {
      user = await storage.createUser({
        id: interaction.user.id,
        username: interaction.user.username,
        discriminator: interaction.user.discriminator,
        avatar: interaction.user.avatar,
      });
    }

    const xpNeeded = (user.level + 1) * 100;
    const xpProgress = Math.floor((user.xp / xpNeeded) * 100);

    const embed = new EmbedBuilder()
      .setColor(0x5865F2)
      .setTitle(`⭐ ${interaction.user.username}'s Rank`)
      .setThumbnail(interaction.user.displayAvatarURL())
      .addFields(
        { name: 'Level', value: `${user.level}`, inline: true },
        { name: 'XP', value: `${user.xp}/${xpNeeded}`, inline: true },
        { name: 'Progress', value: `${xpProgress}%`, inline: true },
        { name: 'Total Messages', value: `${user.totalMessages.toLocaleString()}` }
      )
      .setTimestamp();

    await interaction.reply({ embeds: [embed] });
  },
};
