import { SlashCommandBuilder, ChatInputCommandInteraction, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } from 'discord.js';
import { IStorage } from '../../storage';

export const blackjackCommand = {
  data: new SlashCommandBuilder()
    .setName('blackjack')
    .setDescription('Play a game of BlackJack')
    .addIntegerOption(option =>
      option.setName('bet')
        .setDescription('Amount to bet')
        .setRequired(true)
        .setMinValue(10)
    ),
  async execute(interaction: ChatInputCommandInteraction, storage: IStorage) {
    const bet = interaction.options.getInteger('bet', true);
    
    let user = await storage.getUser(interaction.user.id);
    if (!user) {
      user = await storage.createUser({
        id: interaction.user.id,
        username: interaction.user.username,
        discriminator: interaction.user.discriminator,
        avatar: interaction.user.avatar,
      });
    }

    if (user.balance < bet) {
      return interaction.reply({
        content: `❌ You don't have enough coins! You only have **${user.balance} coins**.`,
        ephemeral: true,
      });
    }

    // Simple blackjack simulation
    const dealerHand = Math.floor(Math.random() * 11) + 15; // 15-25
    const playerHand = Math.floor(Math.random() * 11) + 15; // 15-25

    const won = playerHand > dealerHand || dealerHand > 21;
    const winAmount = won ? bet : -bet;

    await storage.updateUserBalance(interaction.user.id, user.balance + winAmount, user.bank);

    const embed = new EmbedBuilder()
      .setColor(won ? 0x57F287 : 0xED4245)
      .setTitle('🎰 BlackJack')
      .addFields(
        { name: 'Your Hand', value: `${playerHand}`, inline: true },
        { name: 'Dealer Hand', value: `${dealerHand}`, inline: true },
        { name: 'Result', value: won ? `You won ${bet} coins!` : `You lost ${bet} coins!` }
      )
      .setFooter({ text: `New balance: ${(user.balance + winAmount).toLocaleString()} coins` })
      .setTimestamp();

    await interaction.reply({ embeds: [embed] });
  },
};

export const coinflipCommand = {
  data: new SlashCommandBuilder()
    .setName('coinflip')
    .setDescription('Flip a coin and bet on the outcome')
    .addIntegerOption(option =>
      option.setName('bet')
        .setDescription('Amount to bet')
        .setRequired(true)
        .setMinValue(10)
    )
    .addStringOption(option =>
      option.setName('side')
        .setDescription('Choose heads or tails')
        .setRequired(true)
        .addChoices(
          { name: 'Heads', value: 'heads' },
          { name: 'Tails', value: 'tails' }
        )
    ),
  async execute(interaction: ChatInputCommandInteraction, storage: IStorage) {
    const bet = interaction.options.getInteger('bet', true);
    const choice = interaction.options.getString('side', true);
    
    let user = await storage.getUser(interaction.user.id);
    if (!user) {
      user = await storage.createUser({
        id: interaction.user.id,
        username: interaction.user.username,
        discriminator: interaction.user.discriminator,
        avatar: interaction.user.avatar,
      });
    }

    if (user.balance < bet) {
      return interaction.reply({
        content: `❌ You don't have enough coins! You only have **${user.balance} coins**.`,
        ephemeral: true,
      });
    }

    const result = Math.random() > 0.5 ? 'heads' : 'tails';
    const won = result === choice;
    const winAmount = won ? bet : -bet;

    await storage.updateUserBalance(interaction.user.id, user.balance + winAmount, user.bank);

    const embed = new EmbedBuilder()
      .setColor(won ? 0x57F287 : 0xED4245)
      .setTitle('🪙 Coinflip')
      .setDescription(`The coin landed on: **${result.toUpperCase()}**`)
      .addFields(
        { name: 'Your Choice', value: choice.toUpperCase(), inline: true },
        { name: 'Result', value: won ? `You won ${bet} coins!` : `You lost ${bet} coins!`, inline: true }
      )
      .setFooter({ text: `New balance: ${(user.balance + winAmount).toLocaleString()} coins` })
      .setTimestamp();

    await interaction.reply({ embeds: [embed] });
  },
};

export const diceCommand = {
  data: new SlashCommandBuilder()
    .setName('dice')
    .setDescription('Roll the dice'),
  async execute(interaction: ChatInputCommandInteraction, storage: IStorage) {
    const roll1 = Math.floor(Math.random() * 6) + 1;
    const roll2 = Math.floor(Math.random() * 6) + 1;
    const total = roll1 + roll2;

    const diceEmojis = ['⚀', '⚁', '⚂', '⚃', '⚄', '⚅'];

    const embed = new EmbedBuilder()
      .setColor(0x5865F2)
      .setTitle('🎲 Dice Roll')
      .setDescription(`${diceEmojis[roll1 - 1]} ${diceEmojis[roll2 - 1]}`)
      .addFields({ name: 'Total', value: `**${total}**` })
      .setTimestamp();

    await interaction.reply({ embeds: [embed] });
  },
};

export const triviaCommand = {
  data: new SlashCommandBuilder()
    .setName('trivia')
    .setDescription('Answer a trivia question'),
  async execute(interaction: ChatInputCommandInteraction, storage: IStorage) {
    const question = await storage.getRandomTriviaQuestion();

    if (!question) {
      return interaction.reply({
        content: '❌ No trivia questions available! Ask an admin to add some.',
        ephemeral: true,
      });
    }

    // Shuffle answers
    const allAnswers = [question.correctAnswer, ...question.wrongAnswers].sort(() => Math.random() - 0.5);

    const embed = new EmbedBuilder()
      .setColor(0x5865F2)
      .setTitle('❓ Trivia Question')
      .setDescription(question.question)
      .addFields(
        ...allAnswers.map((answer, i) => ({
          name: `${['A', 'B', 'C', 'D'][i]}`,
          value: answer,
          inline: false,
        }))
      )
      .setFooter({ text: `Category: ${question.category} | Difficulty: ${question.difficulty}` });

    const row = new ActionRowBuilder<ButtonBuilder>()
      .addComponents(
        ...allAnswers.map((answer, i) =>
          new ButtonBuilder()
            .setCustomId(`trivia_${question.id}_${answer}`)
            .setLabel(['A', 'B', 'C', 'D'][i])
            .setStyle(ButtonStyle.Primary)
        )
      );

    await interaction.reply({ embeds: [embed], components: [row] });

    // Note: Button interaction handling would be in a separate collector
    // For now, this shows the question structure
  },
};
