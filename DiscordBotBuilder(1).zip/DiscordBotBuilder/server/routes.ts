import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { getBotClient, getBotStats } from "./bot/index";

export async function registerRoutes(app: Express): Promise<Server> {
  // Bot stats endpoint
  app.get("/api/bot/stats", async (req: Request, res: Response) => {
    try {
      const client = getBotClient();
      const stats = getBotStats();
      const totalCommands = await storage.getTotalCommands();

      if (!client) {
        return res.json({
          status: 'offline',
          totalServers: 0,
          totalUsers: 0,
          commandsToday: 0,
          uptimeSeconds: 0,
          totalCommands: 0,
          messagesProcessed: 0,
        });
      }

      const guilds = Array.from(client.guilds.cache.values());
      const totalUsers = guilds.reduce((acc, guild) => acc + guild.memberCount, 0);

      // Get today's command count
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      const commandStats = await storage.getCommandStats(1); // Last 24 hours
      const commandsToday = commandStats.reduce((acc, stat) => acc + stat.count, 0);

      res.json({
        status: client.isReady() ? 'online' : 'offline',
        totalServers: client.guilds.cache.size,
        totalUsers,
        commandsToday,
        uptimeSeconds: stats.uptime,
        totalCommands,
        messagesProcessed: stats.messagesProcessed,
      });
    } catch (error) {
      console.error('Error fetching bot stats:', error);
      res.status(500).json({ error: 'Failed to fetch bot stats' });
    }
  });

  // Command usage stats
  app.get("/api/bot/commands/usage", async (req: Request, res: Response) => {
    try {
      const days = parseInt(req.query.days as string) || 7;
      const commandStats = await storage.getCommandStats(days);

      res.json(commandStats);
    } catch (error) {
      console.error('Error fetching command usage:', error);
      res.status(500).json({ error: 'Failed to fetch command usage' });
    }
  });

  // All commands list
  app.get("/api/bot/commands", async (req: Request, res: Response) => {
    try {
      const commandsList = [
        // Economy
        { name: 'balance', description: 'Check your balance or someone else\'s', category: 'economy', enabled: true },
        { name: 'daily', description: 'Claim your daily reward', category: 'economy', enabled: true },
        { name: 'weekly', description: 'Claim your weekly reward', category: 'economy', enabled: true },
        { name: 'pay', description: 'Send money to another user', category: 'economy', enabled: true },
        { name: 'leaderboard', description: 'View the richest users', category: 'economy', enabled: true },
        
        // Games
        { name: 'blackjack', description: 'Play a game of BlackJack', category: 'games', enabled: true },
        { name: 'coinflip', description: 'Flip a coin and bet on the outcome', category: 'games', enabled: true },
        { name: 'dice', description: 'Roll the dice', category: 'games', enabled: true },
        { name: 'trivia', description: 'Answer a trivia question', category: 'games', enabled: true },
        
        // Moderation
        { name: 'kick', description: 'Kick a member from the server', category: 'moderation', enabled: true },
        { name: 'ban', description: 'Ban a member from the server', category: 'moderation', enabled: true },
        { name: 'timeout', description: 'Timeout a member', category: 'moderation', enabled: true },
        { name: 'warn', description: 'Warn a member', category: 'moderation', enabled: true },
        { name: 'warnings', description: 'View warnings for a user', category: 'moderation', enabled: true },
        { name: 'cleanup', description: 'Delete multiple messages', category: 'moderation', enabled: true },
        
        // Fun
        { name: 'meme', description: 'Get a random meme', category: 'fun', enabled: true },
        { name: 'dog', description: 'Get a random dog picture', category: 'fun', enabled: true },
        { name: 'cat', description: 'Get a random cat picture', category: 'fun', enabled: true },
        { name: '8ball', description: 'Ask the magic 8ball a question', category: 'fun', enabled: true },
        
        // Social
        { name: 'profile', description: 'View your profile or someone else\'s', category: 'social', enabled: true },
        { name: 'inventory', description: 'View your inventory', category: 'social', enabled: true },
        { name: 'achievements', description: 'View your achievements', category: 'social', enabled: true },
        { name: 'rank', description: 'View your rank and level', category: 'social', enabled: true },
      ];

      // Get usage counts from database
      const commandStats = await storage.getCommandStats(30); // Last 30 days
      const usageMap = new Map(commandStats.map(s => [s.name, s.count]));

      const commandsWithUsage = commandsList.map(cmd => ({
        ...cmd,
        usageCount: usageMap.get(cmd.name) || 0,
      }));

      res.json(commandsWithUsage);
    } catch (error) {
      console.error('Error fetching commands:', error);
      res.status(500).json({ error: 'Failed to fetch commands' });
    }
  });

  // Servers list
  app.get("/api/bot/servers", async (req: Request, res: Response) => {
    try {
      const client = getBotClient();
      
      if (!client || !client.isReady()) {
        return res.json([]);
      }

      const guilds = await storage.getAllGuilds();
      const commandStats = await storage.getCommandStats(30);

      // Create a map of guild command usage
      const guildCommandsMap = new Map<string, number>();
      for (const stat of commandStats) {
        if (stat.name) {
          const current = guildCommandsMap.get(stat.name) || 0;
          guildCommandsMap.set(stat.name, current + 1);
        }
      }

      const serversData = guilds.map(guild => {
        const discordGuild = client.guilds.cache.get(guild.id);
        
        return {
          id: guild.id,
          name: guild.name,
          icon: guild.icon,
          memberCount: discordGuild?.memberCount || guild.memberCount,
          commandsUsed: guildCommandsMap.get(guild.id) || 0,
          economyEnabled: guild.economyEnabled,
          levelsEnabled: guild.levelsEnabled,
          moderationEnabled: guild.moderationEnabled,
        };
      });

      res.json(serversData);
    } catch (error) {
      console.error('Error fetching servers:', error);
      res.status(500).json({ error: 'Failed to fetch servers' });
    }
  });

  // Get specific guild settings
  app.get("/api/guilds/:guildId", async (req: Request, res: Response) => {
    try {
      const guild = await storage.getGuild(req.params.guildId);
      
      if (!guild) {
        return res.status(404).json({ error: 'Guild not found' });
      }

      res.json(guild);
    } catch (error) {
      console.error('Error fetching guild:', error);
      res.status(500).json({ error: 'Failed to fetch guild' });
    }
  });

  // Update guild settings
  app.patch("/api/guilds/:guildId", async (req: Request, res: Response) => {
    try {
      const guildId = req.params.guildId;
      const updates = req.body;

      await storage.updateGuild(guildId, updates);

      res.json({ success: true });
    } catch (error) {
      console.error('Error updating guild:', error);
      res.status(500).json({ error: 'Failed to update guild' });
    }
  });

  // User profile endpoint
  app.get("/api/users/:userId", async (req: Request, res: Response) => {
    try {
      const user = await storage.getUser(req.params.userId);
      
      if (!user) {
        return res.status(404).json({ error: 'User not found' });
      }

      const achievements = await storage.getUserAchievements(user.id);
      const inventory = await storage.getUserInventory(user.id);

      res.json({
        ...user,
        achievements,
        inventory,
      });
    } catch (error) {
      console.error('Error fetching user:', error);
      res.status(500).json({ error: 'Failed to fetch user' });
    }
  });

  // Leaderboard endpoint
  app.get("/api/leaderboard", async (req: Request, res: Response) => {
    try {
      const limit = parseInt(req.query.limit as string) || 10;
      const users = await storage.getUsersLeaderboard(limit);

      res.json(users);
    } catch (error) {
      console.error('Error fetching leaderboard:', error);
      res.status(500).json({ error: 'Failed to fetch leaderboard' });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
