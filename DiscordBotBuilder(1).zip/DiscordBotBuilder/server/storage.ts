// Referenced from blueprint:javascript_database
import { 
  users, guilds, inventory, achievements, warnings, commandStats, triviaQuestions, triviaScores,
  type User, type InsertUser,
  type Guild, type InsertGuild,
  type Inventory, type InsertInventory,
  type Achievement, type InsertAchievement,
  type Warning, type InsertWarning,
  type CommandStat, type InsertCommandStat,
  type TriviaQuestion, type InsertTriviaQuestion,
  type TriviaScore, type InsertTriviaScore
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, and, gte, sql } from "drizzle-orm";

export interface IStorage {
  // Users
  getUser(id: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUserBalance(id: string, balance: number, bank: number): Promise<void>;
  updateDailyClaim(id: string, balance: number): Promise<void>;
  updateWeeklyClaim(id: string, balance: number): Promise<void>;
  updateUserXP(id: string, xp: number, level: number): Promise<void>;
  getUsersLeaderboard(limit?: number): Promise<User[]>;
  
  // Guilds
  getGuild(id: string): Promise<Guild | undefined>;
  createGuild(guild: InsertGuild): Promise<Guild>;
  updateGuild(id: string, updates: Partial<InsertGuild>): Promise<void>;
  getAllGuilds(): Promise<Guild[]>;
  
  // Inventory
  getUserInventory(userId: string): Promise<Inventory[]>;
  addInventoryItem(item: InsertInventory): Promise<Inventory>;
  
  // Achievements
  getUserAchievements(userId: string): Promise<Achievement[]>;
  addAchievement(achievement: InsertAchievement): Promise<Achievement>;
  
  // Moderation
  getGuildWarnings(guildId: string): Promise<Warning[]>;
  getUserWarnings(guildId: string, userId: string): Promise<Warning[]>;
  addWarning(warning: InsertWarning): Promise<Warning>;
  
  // Command Stats
  logCommandUsage(stat: InsertCommandStat): Promise<void>;
  getCommandStats(days?: number): Promise<{ name: string; count: number }[]>;
  getTotalCommands(): Promise<number>;
  
  // Trivia
  getRandomTriviaQuestion(): Promise<TriviaQuestion | undefined>;
  getUserTriviaScore(userId: string): Promise<TriviaScore | undefined>;
  updateTriviaScore(userId: string, correct: number, wrong: number, streak: number): Promise<void>;
}

export class DatabaseStorage implements IStorage {
  // Users
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(insertUser)
      .onConflictDoUpdate({
        target: users.id,
        set: { lastSeen: sql`NOW()` }
      })
      .returning();
    return user;
  }

  async updateUserBalance(id: string, balance: number, bank: number): Promise<void> {
    await db
      .update(users)
      .set({ balance, bank })
      .where(eq(users.id, id));
  }

  async updateDailyClaim(id: string, balance: number): Promise<void> {
    await db
      .update(users)
      .set({ balance, lastDaily: sql`NOW()` })
      .where(eq(users.id, id));
  }

  async updateWeeklyClaim(id: string, balance: number): Promise<void> {
    await db
      .update(users)
      .set({ balance, lastWeekly: sql`NOW()` })
      .where(eq(users.id, id));
  }

  async updateUserXP(id: string, xp: number, level: number): Promise<void> {
    await db
      .update(users)
      .set({ xp, level, totalMessages: sql`${users.totalMessages} + 1` })
      .where(eq(users.id, id));
  }

  async getUsersLeaderboard(limit: number = 10): Promise<User[]> {
    return await db.select().from(users).orderBy(desc(users.level), desc(users.xp)).limit(limit);
  }

  // Guilds
  async getGuild(id: string): Promise<Guild | undefined> {
    const [guild] = await db.select().from(guilds).where(eq(guilds.id, id));
    return guild || undefined;
  }

  async createGuild(insertGuild: InsertGuild): Promise<Guild> {
    const [guild] = await db
      .insert(guilds)
      .values(insertGuild)
      .onConflictDoUpdate({
        target: guilds.id,
        set: { name: insertGuild.name, icon: insertGuild.icon }
      })
      .returning();
    return guild;
  }

  async updateGuild(id: string, updates: Partial<InsertGuild>): Promise<void> {
    await db
      .update(guilds)
      .set(updates)
      .where(eq(guilds.id, id));
  }

  async getAllGuilds(): Promise<Guild[]> {
    return await db.select().from(guilds);
  }

  // Inventory
  async getUserInventory(userId: string): Promise<Inventory[]> {
    return await db.select().from(inventory).where(eq(inventory.userId, userId));
  }

  async addInventoryItem(item: InsertInventory): Promise<Inventory> {
    const [newItem] = await db
      .insert(inventory)
      .values(item)
      .returning();
    return newItem;
  }

  // Achievements
  async getUserAchievements(userId: string): Promise<Achievement[]> {
    return await db.select().from(achievements).where(eq(achievements.userId, userId));
  }

  async addAchievement(achievement: InsertAchievement): Promise<Achievement> {
    const [newAchievement] = await db
      .insert(achievements)
      .values(achievement)
      .onConflictDoNothing()
      .returning();
    return newAchievement;
  }

  // Moderation
  async getGuildWarnings(guildId: string): Promise<Warning[]> {
    return await db.select().from(warnings).where(eq(warnings.guildId, guildId)).orderBy(desc(warnings.createdAt));
  }

  async getUserWarnings(guildId: string, userId: string): Promise<Warning[]> {
    return await db
      .select()
      .from(warnings)
      .where(and(eq(warnings.guildId, guildId), eq(warnings.userId, userId)))
      .orderBy(desc(warnings.createdAt));
  }

  async addWarning(warning: InsertWarning): Promise<Warning> {
    const [newWarning] = await db
      .insert(warnings)
      .values(warning)
      .returning();
    return newWarning;
  }

  // Command Stats
  async logCommandUsage(stat: InsertCommandStat): Promise<void> {
    await db.insert(commandStats).values(stat);
  }

  async getCommandStats(days: number = 7): Promise<{ name: string; count: number }[]> {
    const since = new Date();
    since.setDate(since.getDate() - days);

    const result = await db
      .select({
        name: commandStats.commandName,
        count: sql<number>`COUNT(*)::int`
      })
      .from(commandStats)
      .where(gte(commandStats.executedAt, since))
      .groupBy(commandStats.commandName)
      .orderBy(desc(sql`COUNT(*)`));

    return result;
  }

  async getTotalCommands(): Promise<number> {
    const result = await db
      .select({ count: sql<number>`COUNT(*)::int` })
      .from(commandStats);
    return result[0]?.count || 0;
  }

  // Trivia
  async getRandomTriviaQuestion(): Promise<TriviaQuestion | undefined> {
    const [question] = await db
      .select()
      .from(triviaQuestions)
      .orderBy(sql`RANDOM()`)
      .limit(1);
    return question || undefined;
  }

  async getUserTriviaScore(userId: string): Promise<TriviaScore | undefined> {
    const [score] = await db
      .select()
      .from(triviaScores)
      .where(eq(triviaScores.userId, userId));
    return score || undefined;
  }

  async updateTriviaScore(userId: string, correct: number, wrong: number, streak: number): Promise<void> {
    await db
      .insert(triviaScores)
      .values({ userId, correct, wrong, streak })
      .onConflictDoUpdate({
        target: triviaScores.userId,
        set: { correct, wrong, streak }
      });
  }
}

export const storage = new DatabaseStorage();
