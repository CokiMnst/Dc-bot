# HELLBORNTV Discord Bot - Comprehensive Bot System

## Project Overview
Full-featured Discord bot with economy, games, moderation, levels, and a professional web management dashboard.

## Architecture
- **Frontend**: React + TypeScript + Tailwind CSS (Discord-themed dark mode dashboard)
- **Backend**: Express.js + Discord.js v14 (Slash commands)
- **Database**: PostgreSQL (Neon) - User data, economy, stats, moderation
- **Bot Framework**: Discord.js with slash command handlers

## Key Features

### Discord Bot Features
1. **Economy System**
   - Balance & bank accounts
   - Daily/weekly rewards
   - Money transfers between users
   - Shop system with items

2. **Mini Games**
   - BlackJack (21 card game)
   - Coinflip (gambling)
   - Dice rolls
   - Trivia (multiple choice questions)

3. **Level/XP System**
   - XP gained from messages
   - Level up notifications
   - Leaderboards
   - Role rewards on level milestones

4. **Moderation**
   - Kick/Ban/Timeout users
   - Warning system
   - Message cleanup
   - Moderation logs

5. **Fun Commands**
   - OwO-style random reactions
   - Animal pictures (dogs, cats)
   - Meme responses
   - Random fun interactions

6. **Social Features**
   - User profiles with stats
   - Inventory system
   - Achievements/badges
   - Activity tracking

7. **Auto Responses**
   - Welcome messages for new members
   - Level up announcements
   - Custom trigger responses

### Web Dashboard Features
1. **Overview Dashboard**
   - Real-time bot status
   - Server count & user metrics
   - Command usage statistics
   - Activity feed

2. **Command Management**
   - View all slash commands
   - Filter by category
   - Usage statistics
   - Enable/disable toggle

3. **Server Management**
   - List all servers bot is in
   - Per-server configuration
   - Member counts
   - Feature toggles

4. **Settings Panel**
   - Bot configuration
   - Economy settings
   - Moderation rules
   - Notification preferences

## Database Schema

### Tables
- `users` - Discord user profiles, economy, XP/levels
- `guilds` - Server configurations
- `inventory` - User items and collectibles
- `achievements` - Unlocked badges
- `warnings` - Moderation warnings
- `command_stats` - Usage tracking
- `trivia_questions` - Question bank
- `trivia_scores` - User trivia performance

## File Structure

```
/server
  /bot - Discord bot code
    index.ts - Main bot entry
    /commands - Slash command handlers
    /events - Discord event handlers
  routes.ts - Web API endpoints
  storage.ts - Database operations
  db.ts - Database connection

/client
  /src
    /pages - Dashboard, Commands, Servers, Settings
    /components - Reusable UI components
    App.tsx - Main React app with routing

/shared
  schema.ts - Database models & types
```

## Environment Variables
- `BOT_TOKEN` - Discord bot token
- `CLIENT_ID` - Discord application ID
- `GUILD_ID` - Test server ID (for command deployment)
- `DATABASE_URL` - PostgreSQL connection string
- `SESSION_SECRET` - Express session secret

## Development Commands
- `npm run dev` - Start both bot and web server
- `npm run db:push` - Push schema changes to database

## Bot Commands (All Slash Commands)

### Economy
- `/balance` - Check your balance
- `/daily` - Claim daily reward
- `/weekly` - Claim weekly reward
- `/pay @user amount` - Send money to another user
- `/leaderboard` - Top richest users

### Games
- `/blackjack bet` - Play BlackJack
- `/coinflip bet side` - Flip a coin
- `/dice` - Roll the dice
- `/trivia` - Answer trivia questions

### Moderation
- `/kick @user reason` - Kick a member
- `/ban @user reason` - Ban a member
- `/timeout @user duration` - Timeout a user
- `/warn @user reason` - Warn a user
- `/warnings @user` - View user warnings
- `/cleanup amount` - Delete messages

### Fun
- `/meme` - Random meme
- `/dog` - Random dog picture
- `/cat` - Random cat picture
- `/8ball question` - Ask the magic 8ball

### Social
- `/profile [@user]` - View user profile
- `/inventory` - View your items
- `/achievements` - View your badges
- `/rank` - Your level and XP

### Info
- `/about` - Bot information and links
- `/sponsor` - Sponsor information
- `/help` - Command list

## Recent Changes
- Initial setup complete
- Database schema defined
- Web dashboard frontend built
- Storage layer implemented
- Ready for Discord bot backend implementation

## Next Steps
1. Implement Discord bot with slash commands
2. Create all command handlers
3. Connect web API endpoints
4. Test all features
5. Deploy bot

## Notes
- Dark mode only (Discord-inspired theme)
- Mobile responsive dashboard
- Real-time stats updates
- PostgreSQL for data persistence
- All commands use Discord's slash command system (modern standard)
