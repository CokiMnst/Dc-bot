import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import Dashboard from "@/pages/Dashboard";
import Commands from "@/pages/Commands";
import Servers from "@/pages/Servers";
import Settings from "@/pages/Settings";
import Sidebar from "@/components/Sidebar";
import MobileNav from "@/components/MobileNav";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Dashboard} />
      <Route path="/commands" component={Commands} />
      <Route path="/servers" component={Servers} />
      <Route path="/settings" component={Settings} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <div className="min-h-screen bg-background">
          <Sidebar />
          <MobileNav />
          
          <div className="md:pl-64">
            <main className="py-6 px-4 sm:px-6 lg:px-8 mt-16 md:mt-0">
              <div className="max-w-7xl mx-auto">
                <Router />
              </div>
            </main>
          </div>
        </div>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
