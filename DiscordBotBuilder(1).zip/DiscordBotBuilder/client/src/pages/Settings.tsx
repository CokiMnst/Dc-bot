import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Save, Bot, DollarSign, Shield, Bell } from "lucide-react";
import { Separator } from "@/components/ui/separator";

export default function Settings() {
  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold" data-testid="text-settings-title">Settings</h1>
        <p className="text-muted-foreground mt-1">Configure bot behavior and features</p>
      </div>

      <Tabs defaultValue="general" className="space-y-6">
        <TabsList>
          <TabsTrigger value="general" data-testid="tab-general">
            <Bot className="h-4 w-4 mr-2" />
            General
          </TabsTrigger>
          <TabsTrigger value="economy" data-testid="tab-economy">
            <DollarSign className="h-4 w-4 mr-2" />
            Economy
          </TabsTrigger>
          <TabsTrigger value="moderation" data-testid="tab-moderation">
            <Shield className="h-4 w-4 mr-2" />
            Moderation
          </TabsTrigger>
          <TabsTrigger value="notifications" data-testid="tab-notifications">
            <Bell className="h-4 w-4 mr-2" />
            Notifications
          </TabsTrigger>
        </TabsList>

        {/* General Settings */}
        <TabsContent value="general" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Bot Configuration</CardTitle>
              <CardDescription>Basic bot settings and behavior</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-2">
                <Label htmlFor="bot-name">Bot Display Name</Label>
                <Input id="bot-name" defaultValue="HELLBORNTV Bot" data-testid="input-bot-name" />
              </div>

              <Separator />

              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label htmlFor="levels-enabled">Level System</Label>
                  <p className="text-sm text-muted-foreground">Track user XP and levels</p>
                </div>
                <Switch id="levels-enabled" defaultChecked data-testid="switch-levels" />
              </div>

              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label htmlFor="economy-enabled">Economy System</Label>
                  <p className="text-sm text-muted-foreground">Enable currency and transactions</p>
                </div>
                <Switch id="economy-enabled" defaultChecked data-testid="switch-economy" />
              </div>

              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label htmlFor="games-enabled">Mini Games</Label>
                  <p className="text-sm text-muted-foreground">BlackJack, Trivia, and more</p>
                </div>
                <Switch id="games-enabled" defaultChecked data-testid="switch-games" />
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Economy Settings */}
        <TabsContent value="economy" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Economy Configuration</CardTitle>
              <CardDescription>Manage currency and rewards</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid gap-4 md:grid-cols-2">
                <div className="space-y-2">
                  <Label htmlFor="daily-reward">Daily Reward</Label>
                  <Input 
                    id="daily-reward" 
                    type="number" 
                    defaultValue="1000" 
                    data-testid="input-daily-reward"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="weekly-reward">Weekly Reward</Label>
                  <Input 
                    id="weekly-reward" 
                    type="number" 
                    defaultValue="5000" 
                    data-testid="input-weekly-reward"
                  />
                </div>
              </div>

              <Separator />

              <div className="space-y-2">
                <Label htmlFor="starting-balance">Starting Balance</Label>
                <Input 
                  id="starting-balance" 
                  type="number" 
                  defaultValue="100" 
                  data-testid="input-starting-balance"
                />
                <p className="text-xs text-muted-foreground">Initial balance for new users</p>
              </div>

              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label htmlFor="transfer-enabled">Allow Transfers</Label>
                  <p className="text-sm text-muted-foreground">Users can send money to each other</p>
                </div>
                <Switch id="transfer-enabled" defaultChecked data-testid="switch-transfers" />
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Moderation Settings */}
        <TabsContent value="moderation" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Moderation Tools</CardTitle>
              <CardDescription>Configure auto-moderation and logging</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label htmlFor="auto-mod">Auto-Moderation</Label>
                  <p className="text-sm text-muted-foreground">Automatically filter spam and bad words</p>
                </div>
                <Switch id="auto-mod" data-testid="switch-auto-mod" />
              </div>

              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label htmlFor="log-actions">Log Moderation Actions</Label>
                  <p className="text-sm text-muted-foreground">Keep track of warnings and bans</p>
                </div>
                <Switch id="log-actions" defaultChecked data-testid="switch-log-actions" />
              </div>

              <Separator />

              <div className="space-y-2">
                <Label htmlFor="max-warnings">Max Warnings Before Ban</Label>
                <Input 
                  id="max-warnings" 
                  type="number" 
                  defaultValue="3" 
                  min="1"
                  max="10"
                  data-testid="input-max-warnings"
                />
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Notifications Settings */}
        <TabsContent value="notifications" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Notification Settings</CardTitle>
              <CardDescription>Configure welcome messages and alerts</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label htmlFor="welcome-enabled">Welcome Messages</Label>
                  <p className="text-sm text-muted-foreground">Greet new members</p>
                </div>
                <Switch id="welcome-enabled" defaultChecked data-testid="switch-welcome" />
              </div>

              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label htmlFor="levelup-enabled">Level Up Notifications</Label>
                  <p className="text-sm text-muted-foreground">Announce when users level up</p>
                </div>
                <Switch id="levelup-enabled" defaultChecked data-testid="switch-levelup" />
              </div>

              <Separator />

              <div className="space-y-2">
                <Label htmlFor="welcome-message">Welcome Message Template</Label>
                <Input 
                  id="welcome-message" 
                  defaultValue="Welcome {user} to {server}! 🎉" 
                  data-testid="input-welcome-message"
                />
                <p className="text-xs text-muted-foreground">Use {"{user}"} and {"{server}"} as placeholders</p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Save Button */}
      <div className="flex justify-end">
        <Button size="lg" data-testid="button-save-settings">
          <Save className="h-4 w-4 mr-2" />
          Save Changes
        </Button>
      </div>
    </div>
  );
}
